#ifndef _POINT_H_
#define _POINT_H_

class Point
{

public:
	Point(int x, int y);
	int getX();
	int getY();
	void serialize(std::istream&);


private:
	int x;
	int y;

};
#endif