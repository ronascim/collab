#include "Point.h"
#include "VectorGraphic.h"

int main(int argc, char * argv[])
{
	//Open XML file
	
	//Read the file(use regex to read value of x, y) from file. 

	//Close XML file

	//Call addPoint(), add points (x,y) 

	//Create new XML file (open for writing)

	//Call method serialize on the vectorgraphic

	//Close XML file 
}