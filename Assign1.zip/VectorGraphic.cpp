#include "VectorGraphic.h"
#include "Point.h"

VectorGraphic::VectorGraphic()
{


}


void VectorGraphic::addPoint(int point)
{
	
}

int VectorGraphic::getPointCount()
{
	return;
}

int VectorGraphic::getWidth()
{
	return this->width;
}

int VectorGraphic::getHeight()
{
	return this->height;
}

bool VectorGraphic::isClosed()
{
	return true;
}

bool VectorGraphic::isOpen()
{
	return true;
}
 

