#ifndef _VECTORGRAPHIC_H_
#define _VECTORGRAPHIC_H_
#include <vector>

using Points = std::vector<Point>;
class VectorGraphic
{
public:
    VectorGraphic();
    ~VectorGraphic();

    void addPoint(const Point& p);
    void removePoint(const Point& p);
    void erasePoint(int index);

    void openShape();
    void closeShape();

    bool isOpen() const;
    bool isClosed() const;

    int getWidth() const;
    int getHeight() const;

    int getPointCount() const;
    Point getPoint(int index) const;

    void serialize(std::istream &);

private:
    Points myPath;
#endif
