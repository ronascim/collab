#include "Point.h"
#include "Point.h"

Point::Point(int x, int y)
{
}

int Point::getX()
{
	return this->x;
}

int Point::getY()
{
	return this->y;
}
